#!/bin/bash
set -e

cd code/build.linux

# Step 1: Regenerate dependencies (only if needed)
if [ ! -f makedep ] || [ makedep -ot ../lib/bitmap.cc ]; then
    echo "Regenerating dependencies..."
    make depend
fi

# Step 2: Build all object files
make -B

# Step 3: Run Nachos
./nachos

